<script lang="ts">
	
	import ListaFotos from "./Components/ListaFotos.svelte"
	import NavBar from "./Components/NavBar.svelte"

</script>
  
<main>
<NavBar/>


</main>


<style>

</style>